#!/usr/bin/env python3
"""Verify an actual local MP3 upload without a browser.

Exit zero means the HTTP, persistence, and predeclared outcome checks passed.
The receipt separately preserves the producer's scientific status. An expected
inconclusive response is never counted as supported localization or accuracy.
The existing browser verifier is independent and remains unchanged.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import http.client
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import uuid

import aircraft_geoloc
from aircraft_geoloc.contracts import validate_request, validate_result
from aircraft_geoloc.jobs import TERMINAL, write_json


def sha256(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def remaining(deadline):
    value = deadline - time.monotonic()
    if value <= 0:
        raise TimeoutError("HTTP verification exceeded its declared time budget")
    return value


class LocalClient:
    """Direct loopback HTTP; proxy environment variables are not consulted."""

    def __init__(self, port, deadline):
        self.port, self.deadline = port, deadline

    def request(self, method, path, *, body=None, headers=None, destination=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port,
                                                timeout=min(30, remaining(self.deadline)))
        try:
            connection.request(method, path, body=body, headers=headers or {})
            response = connection.getresponse()
            if destination is not None:
                with Path(destination).open("xb") as target:
                    while block := response.read(1024 * 1024):
                        remaining(self.deadline)
                        target.write(block)
                return response.status, None
            payload = response.read(64 * 1024 * 1024 + 1)
            if len(payload) > 64 * 1024 * 1024:
                raise ValueError("HTTP JSON response exceeds the verifier's 64 MiB limit")
            return response.status, json.loads(payload)
        finally:
            connection.close()

    def get(self, path):
        code, value = self.request("GET", path)
        if code != 200:
            raise RuntimeError(f"GET {path} returned HTTP {code}")
        return value


def wait_for_service(process, log_path, deadline):
    while True:
        if process.poll() is not None:
            raise RuntimeError("Upload service exited during startup; inspect service.log")
        match = re.search(r"DOPPLERGEIST: http://127\.0\.0\.1:(\d+) ", log_path.read_text())
        if match:
            return LocalClient(int(match.group(1)), deadline)
        time.sleep(min(0.05, remaining(deadline)))


def poll_job(client, job_id, history_path, *, interval_s):
    with history_path.open("x") as history:
        previous = None
        while True:
            value = client.get(f"/api/jobs/{job_id}")
            validate_result(value)
            if value["job_id"] != job_id:
                raise ValueError("Polled result belongs to a different job")
            if value != previous:
                history.write(json.dumps({"observed_utc": now(), "result": value}, allow_nan=False) + "\n")
                history.flush()
                previous = value
            if value["status"] in TERMINAL:
                return value
            time.sleep(min(interval_s, remaining(client.deadline)))


def inspect_job(directory, final, wire, operator, original, implementation):
    """Check actual persisted evidence without changing it or opening truth."""
    read = lambda path: json.loads((directory / path).read_text())
    input_record, stored_request = read("input.json"), read("request.json")
    if input_record != {"sha256": sha256(original), "bytes": original.stat().st_size, "path": "input.mp3"}:
        raise ValueError("Persisted input receipt does not describe the submitted bytes")
    if sha256(directory / "input.mp3") != input_record["sha256"]:
        raise ValueError("Persisted original differs from the submitted MP3")
    uploaded = Path(stored_request.pop("audio_path"))
    if uploaded != directory / "input.mp3" or stored_request != wire:
        raise ValueError("Persisted request differs from the submitted request")
    if read("operator.json") != operator:
        raise ValueError("Persisted operator configuration differs from the submitted configuration")
    if read("result.json") != final:
        raise ValueError("Persisted terminal result differs from the HTTP result")
    provenance = read("provenance.json")
    if (provenance.get("source_sha256") != input_record["sha256"]
            or provenance.get("implementation_files") != implementation):
        raise ValueError("Automatic provenance does not identify the submitted input and executed source")
    if final.get("recording", {}).get("source_sha256", input_record["sha256"]) != input_record["sha256"]:
        raise ValueError("Decoded recording identifies a different source")
    if (directory / "decision.json").exists():
        decision = read("decision.json")
        if any(decision.get(key) != final.get(key) for key in ("status", "reason_code", "candidates")):
            raise ValueError("Persisted scientific decision differs from the terminal result")
    return {"original_preserved": True, "request_preserved": True,
            "operator_preserved": True, "result_preserved": True,
            "automatic_provenance_verified": True}


def verify_http(audio, output, *, request=None, operator=None, expect_status,
                expect_reason=None, timeout_s=600.0, poll_interval_s=0.25):
    if expect_status not in TERMINAL:
        raise ValueError("Declare an expected terminal status before execution")
    for name, value in (("timeout_s", timeout_s), ("poll_interval_s", poll_interval_s)):
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be finite and positive")
    audio = Path(audio).resolve(strict=True)
    if audio.suffix.lower() != ".mp3" or not audio.is_file():
        raise ValueError("Supply a local MP3 file")
    wire = dict(validate_request(dict(request or {"schema_version": 1}, audio_path=str(audio))))
    wire.pop("audio_path")
    operator = {} if operator is None else operator
    if not isinstance(operator, dict):
        raise ValueError("Operator configuration must be a JSON object")
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    write_json(output / "upload-request.json", wire)
    write_json(output / "operator.json", operator)
    package = Path(aircraft_geoloc.__file__).resolve().parent
    implementation = {path.name: sha256(path) for path in sorted(package.glob("*.py"))}
    began, process, final, log = time.monotonic(), None, None, None
    deadline = began + timeout_s
    receipt = {"schema_version": 1, "scope": "actual_local_http_upload_verification",
        "started_utc": now(), "expected_status": expect_status, "expected_reason": expect_reason,
        "timeout_s": timeout_s, "source_sha256": sha256(audio), "source_bytes": audio.stat().st_size,
        "request": wire, "implementation_files": implementation, "verifier_sha256": sha256(__file__),
        "python_executable": sys.executable, "python_version": sys.version,
        "verification_passed": False, "http_checks_passed": False, "supported_decision": False,
        "location_accuracy_evaluated": False, "browser_verified": False,
        "limitations": ["HTTP verification does not establish location accuracy or browser behavior.",
                       "Expected inconclusive or failed responses are preserved, not promoted to localization success.",
                       "This verifier accepts no evaluation labels and performs no ground-truth comparison."],
        "service": {"shutdown_signal": None, "forced_kill": False, "returncode": None}}
    try:
        command = [sys.executable, "-m", "aircraft_geoloc.cli", "serve", "--port", "0",
                   "--jobs", str(output / "jobs"), "--config", str(output / "operator.json"),
                   "--max-runtime", str(timeout_s)]
        receipt["service"]["command"] = command
        env = dict(os.environ, PYTHONPATH=str(package.parent) + os.pathsep + os.environ.get("PYTHONPATH", ""),
                   MPLBACKEND="Agg")
        log = (output / "service.log").open("wb")
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        receipt["service"]["pid"] = process.pid
        client = wait_for_service(process, output / "service.log", deadline)
        receipt["service"]["port"] = client.port
        write_json(output / "capabilities.json", client.get("/api/capabilities"))
        with audio.open("rb") as stream:
            code, queued = client.request("POST", "/api/jobs", body=stream, headers={
                "Content-Type": "application/octet-stream", "Content-Length": str(audio.stat().st_size),
                "X-Filename": "input.mp3", "X-Dopplergeist-Request": json.dumps(wire)})
        write_json(output / "submission.json", {"http_status": code, "response": queued})
        if code != 202:
            raise RuntimeError(f"Upload returned HTTP {code}")
        validate_result(queued)
        job_id = queued["job_id"]
        if uuid.UUID(job_id).hex != job_id:
            raise ValueError("Service returned an invalid job identifier")
        receipt["job_id"] = job_id
        final = poll_job(client, job_id, output / "history.jsonl", interval_s=poll_interval_s)
        write_json(output / "result.json", final)
        receipt.update(status=final["status"], reason_code=final.get("reason_code"),
                       supported_decision=final["status"] == "succeeded",
                       candidate_count=len(final.get("candidates", [])), event_count=len(final.get("events", [])))
        listing = client.get(f"/api/jobs/{job_id}/artifacts")
        write_json(output / "artifacts.json", listing)
        if sum(item["path"] == "input.mp3" for item in listing["artifacts"]) != 1:
            raise ValueError("Artifact listing does not expose exactly one original MP3")
        code, _ = client.request("GET", f"/api/jobs/{job_id}/artifacts/input.mp3",
                                 destination=output / "downloaded-original.mp3")
        if code != 200 or sha256(output / "downloaded-original.mp3") != receipt["source_sha256"]:
            raise ValueError("Downloaded original differs from the submitted MP3")
        if client.get(f"/api/jobs/{job_id}/artifacts/result.json") != final:
            raise ValueError("Downloaded result artifact differs from the terminal HTTP result")
        receipt["checks"] = inspect_job(output / "jobs" / job_id, final, wire, operator, audio, implementation)
        receipt["checks"].update(downloaded_original_verified=True, downloaded_result_verified=True)
        receipt["http_checks_passed"] = True
        receipt["expectation_matched"] = (final["status"] == expect_status
            and (expect_reason is None or final.get("reason_code") == expect_reason))
    except Exception as exc:
        receipt["error"] = f"{type(exc).__name__}: {exc}"
        receipt["timed_out"] = isinstance(exc, TimeoutError)
    finally:
        if process is not None:
            if process.poll() is None:
                receipt["service"].update(shutdown_signal="SIGINT", shutdown_requested_utc=now())
                process.send_signal(signal.SIGINT)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    receipt["service"]["forced_kill"] = True
                    process.kill()
                    process.wait(timeout=5)
            receipt["service"].update(returncode=process.returncode, stopped_utc=now())
        if log is not None:
            log.close()
        try:
            receipt["implementation_unchanged"] = implementation == {
                path.name: sha256(path) for path in sorted(package.glob("*.py"))}
            if final is not None:
                directory = output / "jobs" / final["job_id"]
                receipt["terminal_result_preserved_after_shutdown"] = json.loads((directory / "result.json").read_text()) == final
                files = {path.relative_to(directory).as_posix(): {"bytes": path.stat().st_size, "sha256": sha256(path)}
                         for path in sorted(directory.rglob("*")) if path.is_file() and not path.is_symlink()}
                write_json(output / "job-manifest.json", {"job_id": final["job_id"], "files": files})
            receipt["verification_passed"] = bool(receipt["http_checks_passed"]
                and receipt.get("expectation_matched") and receipt["implementation_unchanged"]
                and receipt.get("terminal_result_preserved_after_shutdown")
                and receipt["service"]["returncode"] == 0 and not receipt["service"]["forced_kill"])
        except Exception as exc:
            receipt["finalization_error"] = f"{type(exc).__name__}: {exc}"
        receipt.update(finished_utc=now(), elapsed_s=time.monotonic() - began)
        write_json(output / "http-verification.json", receipt)
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audio", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="New directory; existing evidence is never overwritten")
    parser.add_argument("--operator-config", type=Path)
    parser.add_argument("--start-utc")
    parser.add_argument("--end-utc")
    parser.add_argument("--time-source", default="Explicit verification recording-start window")
    parser.add_argument("--expect-status", choices=sorted(TERMINAL), required=True)
    parser.add_argument("--expect-reason")
    parser.add_argument("--timeout-s", type=float, default=600)
    parser.add_argument("--poll-interval-s", type=float, default=0.25)
    args = parser.parse_args(argv)
    if args.end_utc and not args.start_utc:
        parser.error("--end-utc requires --start-utc")
    request = {"schema_version": 1, "search": {"coverage": "conus"}}
    if args.start_utc:
        request["time_window"] = {"start_utc": args.start_utc, "end_utc": args.end_utc or args.start_utc,
                                  "source": "user", "source_detail": args.time_source}
    try:
        operator = json.loads(args.operator_config.read_text()) if args.operator_config else {}
        receipt = verify_http(args.audio, args.output, request=request, operator=operator,
            expect_status=args.expect_status, expect_reason=args.expect_reason,
            timeout_s=args.timeout_s, poll_interval_s=args.poll_interval_s)
    except (OSError, ValueError, TypeError) as exc:
        parser.error(str(exc))
    print(json.dumps({"report": str(args.output.resolve() / "http-verification.json"),
                      "verification_passed": receipt["verification_passed"], "status": receipt.get("status"),
                      "reason_code": receipt.get("reason_code"), "supported_decision": receipt["supported_decision"],
                      "location_accuracy_evaluated": False, "error": receipt.get("error")}))
    return 0 if receipt["verification_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
