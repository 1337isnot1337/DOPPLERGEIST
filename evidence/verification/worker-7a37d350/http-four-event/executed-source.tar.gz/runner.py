"""Frozen-source, four-event HTTP development replay; never alters producer decisions."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time

REPO = Path(__file__).resolve().parents[1]
OUTPUT = REPO / "results/http-four-event-7a37d350"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


H = load(REPO / "scripts/ci_upload_replay.py", "four_event_helpers")
R = H.HELPERS
read, write, record = R.read_json, R.write_json, R.file_record
OUTPUT.mkdir(parents=True, exist_ok=False)
(OUTPUT / "logs").mkdir()
began = time.monotonic()
receipt = {"schema_version": 1, "scope": "four_event_synthetic_actual_http_development_replay",
    "started_utc": R.utc_now(), "events_requested": 4, "seed": 20261103,
    "expected_status": "inconclusive", "primary_threshold_m": 1000,
    "thresholds_m": [100, 500, 1000], "evaluation_truth_loaded": False,
    "passed": False, "stages": [], "browser_verified": False,
    "independent_real_accuracy_verified": False, "live_acquisition_verified": False,
    "limitations": ["One synthetic development scene with an exact supplied sample-zero clock.",
        "All generated traffic is retained, but generated completeness is not real-world coverage.",
        "Truth is read only after shutdown; no operating-system isolation of truth is claimed.",
        "An inconclusive producer outcome is not accepted localization.",
        "Process-tree RSS is sampled and may miss peaks or count shared pages twice."]}
write(OUTPUT / "protocol.json", receipt)


def save():
    write(OUTPUT / "acceptance.json", receipt)


def stage(name, command, timeout):
    receipt["stage"] = name
    save()
    print(json.dumps({"stage": name, "started_utc": R.utc_now()}), flush=True)
    result = R.execute(command, snapshot, OUTPUT / "logs" / f"{name}.log", env, timeout)
    receipt["stages"].append({"stage": name, "execution": result})
    save()
    print(json.dumps({"stage": name, "returncode": result.get("returncode"),
                      "elapsed_s": result["elapsed_s"], "timed_out": result.get("timed_out", False)}), flush=True)
    return result


def collect(directory, result, wire, operator, expected_sources, audio):
    checks = {"evidence_collection_complete": False}
    checks["all_stage_artifacts_present"] = all((directory / name).is_file() for name in H.REQUIRED_ARTIFACTS)
    errors = []
    profile = {}
    discovery = {}
    try:
        checks["job_identity_matches"] = result["job_id"] == directory.name
        checks["normal_request_verified"] = read(directory / "request.json") == dict(wire, audio_path=str(directory / "input.mp3"))
        checks["uploaded_bytes_verified"] = record(directory / "input.mp3")["sha256"] == record(audio)["sha256"] == result["recording"]["source_sha256"]
        checks["operator_verified"] = read(directory / "operator.json") == operator
        provenance = read(directory / "provenance.json")
        checks["implementation_verified"] = provenance.get("implementation_files") == expected_sources
        decision = read(directory / "decision.json")
        checks["decision_consistent"] = all(decision.get(key) == result.get(key)
            for key in ("status", "reason_code", "message", "candidates"))
        search = read(directory / "search/search-report.json")
        checks["search_consistent"] = H.search_matches_result(search, result.get("coverage", {}), provenance)
        checks["all_event_groups_considered"] = search.get("all_event_groups_considered") is True
        checks["alternative_evidence_consistent"] = result["status"] != "succeeded" or search.get("alternative_modes_exhaustively_assessed") is True
        discovery = read(directory / "discovery/discovery.json")
        checks["all_discovered_events_retained"] = sorted(discovery["events"], key=lambda event: event["event_id"]) == sorted(result.get("events", []), key=lambda event: event["event_id"])
        profile = H.reported_fit_profile(result, read(directory / "refined-candidates.json"))
        checks["leading_refinement_row_bound"] = profile["leading_row_bound"]
        checks["nominal_joint_fit_recorded"] = profile["nominal_diagnostics_complete"]
        checks["evidence_collection_complete"] = True
        receipt["search"] = {key: search.get(key) for key in (
            "status", "tiles_total", "tiles_completed", "tiles_resumed", "unsearched_tiles", "grid_points",
            "coarse_points", "refined_points", "elapsed_s", "peak_rss_mb", "candidate_retention_limit",
            "all_event_groups_considered", "alternative_modes_exhaustively_assessed", "data_scope_complete",
            "tile_failures", "refinement_failure", "run_hash")}
    except (OSError, KeyError, ValueError, TypeError) as exc:
        errors.append(f"{type(exc).__name__}: {exc}")
    return {"directory": str(directory), "checks": checks, "errors": errors,
        "discovery_settings": discovery.get("settings", {}), "reported_fit_profile": profile,
        "status": result.get("status"), "reason_code": result.get("reason_code"),
        "candidate_count": len(result.get("candidates", [])), "event_count": len(result.get("events", [])),
        "coverage": result.get("coverage")}


try:
    snapshot, source = H.snapshot_sources(REPO, OUTPUT)
    shutil.copy2(REPO / "scripts/verify_upload_http.py", snapshot / "scripts/verify_upload_http.py")
    shutil.copy2(__file__, OUTPUT / "runner.py")
    source["files"] = {path.relative_to(snapshot).as_posix(): record(path)
        for path in sorted(snapshot.rglob("*")) if path.is_file()}
    digest = hashlib.sha256()
    for name, item in source["files"].items():
        digest.update(name.encode() + b"\0" + item["sha256"].encode() + b"\0")
    source["snapshot_sha256"] = digest.hexdigest()
    source["runner"] = record(OUTPUT / "runner.py")
    receipt["implementation"] = source
    write(OUTPUT / "source-manifest.json", source)
    diff = subprocess.run(["git", "-C", str(REPO), "diff", "--", "src/aircraft_geoloc"],
                          capture_output=True, check=True)
    (OUTPUT / "checkout-producer.patch").write_bytes(diff.stdout)
    receipt["runtime"] = R.runtime_record()
    env = dict(os.environ, PYTHONPATH=str(snapshot / "src"), MPLBACKEND="Agg", **R.THREAD_ENV)
    save()
    fixture = OUTPUT / "fixture"
    generation = stage("generation", [sys.executable, str(snapshot / "scripts/make_multi_event_case.py"),
        "--output", str(fixture), "--events", "4", "--seed", "20261103"], 300)
    if generation.get("returncode") != 0 or generation.get("timed_out"):
        raise RuntimeError("Independent four-event fixture generation failed")
    inputs, evaluation = fixture / "inputs", OUTPUT / "evaluation"
    evaluation.mkdir()
    (fixture / "truth").replace(evaluation / "truth")
    (fixture / "generation.json").replace(evaluation / "generation.json")
    index = inputs / "flights.sqlite"
    indexing = stage("indexing", [sys.executable, str(snapshot / "scripts/ci_upload_replay.py"), "_index",
        "--inputs", str(inputs), "--evaluation", str(evaluation), "--index", str(index),
        "--report", str(OUTPUT / "indexing.json"), "--events", "4"], 180)
    if indexing.get("returncode") != 0 or indexing.get("timed_out"):
        raise RuntimeError("Complete generated traffic indexing failed")
    receipt["indexing"] = read(OUTPUT / "indexing.json")
    receipt["input_files"] = {path.name: record(path) for path in sorted(inputs.iterdir()) if path.is_file()}
    wire = H.normal_wire_request(read(inputs / "request.json"))
    write(OUTPUT / "wire-request.json", wire)
    operator = {"flight_indexes": [str(index)], "offline": True,
        "terrain": {"rasters": [str(inputs / "terrain.tif")], "geoid_raster": str(inputs / "geoid.tif")},
        "sound_speed_mps": 343, "max_distance_m": 20000}
    write(OUTPUT / "operator.json", operator)
    receipt["normal_request"], receipt["operator_configuration"] = wire, operator
    http_output = OUTPUT / "http"
    execution = stage("http-upload", [sys.executable, str(snapshot / "scripts/verify_upload_http.py"),
        "--audio", str(inputs / "recording.mp3"), "--operator-config", str(OUTPUT / "operator.json"),
        "--output", str(http_output), "--start-utc", wire["time_window"]["start_utc"],
        "--end-utc", wire["time_window"]["end_utc"], "--time-source", H.TIME_SOURCE,
        "--expect-status", "inconclusive", "--timeout-s", "1800"], 1830)
    http = read(http_output / "http-verification.json")
    result = read(http_output / "result.json")
    receipt["http_verification"] = http
    stopped = (not execution.get("timed_out") and result.get("status") in H.TERMINAL
        and http["service"].get("shutdown_signal") == "SIGINT" and http["service"].get("returncode") == 0
        and http["service"].get("forced_kill") is False and bool(http["service"].get("stopped_utc")))
    receipt["service_and_workers_stopped"] = stopped
    if not stopped:
        raise RuntimeError("Clean service and worker shutdown was not established; labels stay unopened")
    receipt["analysis_stopped_utc"] = R.utc_now()
    directory = http_output / "jobs" / result["job_id"]
    receipt["job"] = collect(directory, result, wire, operator,
        source["expected_implementation_files"], inputs / "recording.mp3")
    receipt["evaluation_truth_load_started_utc"] = R.utc_now()
    labels = read(evaluation / "truth/labels.json")
    mapping = read(evaluation / "flight-id-mapping.json")["original_to_opaque"]
    receipt["evaluation_truth_loaded"] = True
    receipt["evaluation_truth_loaded_utc"] = R.utc_now()
    receipt["evaluation_reference"] = record(evaluation / "truth/labels.json")
    if len(labels["events"]) != 4:
        raise ValueError("The generated reference does not contain exactly four events")
    from pyproj import Geod
    geod = Geod(ellps="WGS84")
    window = receipt["job"]["discovery_settings"].get("window_s")
    tolerance = window / 2 if isinstance(window, (float, int)) else None
    evaluations = H.evaluate_candidates(result, labels, mapping, lambda *xy: geod.inv(*xy)[2],
        tolerance_s=tolerance, request_window=wire["time_window"])
    write(OUTPUT / "candidate-evaluations.json", evaluations)
    receipt["candidate_evaluations"] = evaluations
    receipt["threshold_counts"] = {str(limit): {
        "all_candidates": sum(row.get("within_m", {}).get(str(limit)) is True for row in evaluations),
        "correct_full_flight_set": sum(row.get("within_m", {}).get(str(limit)) is True
            and row.get("full_true_flight_set_correct") is True for row in evaluations)} for limit in H.THRESHOLDS_M}
    acceptance = H.assess(result, evaluations, receipt["job"]["checks"],
        execution.get("returncode") == 0 and http.get("verification_passed") is True, stopped, 4)
    # The existing helper's transport_ui label refers to this HTTP lane only.
    receipt["http_transport_passed"] = acceptance.pop("transport_ui_passed")
    receipt.update(acceptance)
    receipt["stage"] = "complete"
except Exception as exc:
    receipt["error"] = f"{type(exc).__name__}: {exc}"
finally:
    receipt.update(finished_utc=R.utc_now(), elapsed_s=time.monotonic() - began)
    save()
    files = {}
    for path in sorted(OUTPUT.rglob("*")):
        if (not path.is_file() or path.name == "artifact-manifest.json" or "__pycache__" in path.parts
                or (not receipt["evaluation_truth_loaded"] and H.evaluation_path(path, OUTPUT))):
            continue
        files[path.relative_to(OUTPUT).as_posix()] = record(path)
    write(OUTPUT / "artifact-manifest.json", {"files": files,
        "evaluation_files_included": receipt["evaluation_truth_loaded"]})
    print(json.dumps({"report": str(OUTPUT / "acceptance.json"), "stage": receipt.get("stage"),
        "http_transport_passed": receipt.get("http_transport_passed"), "passed": receipt["passed"],
        "scientific_status": receipt.get("job", {}).get("status"),
        "scientific_reason": receipt.get("job", {}).get("reason_code"),
        "leading_error_m": receipt.get("leading_prediction_error_m"),
        "elapsed_s": receipt["elapsed_s"], "error": receipt.get("error")}), flush=True)

raise SystemExit(0 if receipt["passed"] else 1)
