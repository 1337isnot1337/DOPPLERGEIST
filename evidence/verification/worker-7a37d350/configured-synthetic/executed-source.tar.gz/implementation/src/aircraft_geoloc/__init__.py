"""Aircraft-acoustic geolocation reproduction."""
