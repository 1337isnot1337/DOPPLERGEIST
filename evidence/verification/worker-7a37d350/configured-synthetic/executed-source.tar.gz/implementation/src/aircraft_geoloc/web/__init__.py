"""Bundled local upload interface."""
